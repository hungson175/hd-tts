"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Loader2 } from "lucide-react"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ChevronDown } from "lucide-react"

interface TextToSynthesizeTabProps {
  onGenerate: (audioUrl: string, time: number) => void
  isGenerating: boolean
  setIsGenerating: (value: boolean) => void
}

export default function TextToSynthesizeTab({ onGenerate, isGenerating, setIsGenerating }: TextToSynthesizeTabProps) {
  const [text, setText] = useState("Welcome to HD-Voice-Clone. This is a sample text for speech synthesis.")
  const [gender, setGender] = useState("auto")
  const [accent, setAccent] = useState("auto")
  const [emotion, setEmotion] = useState("auto")
  const [speed, setSpeed] = useState([1])
  const [isVoiceCloningOpen, setIsVoiceCloningOpen] = useState(false)

  const handleGenerate = async () => {
    setIsGenerating(true)
    const startTime = Date.now()

    try {
      const response = await fetch("/api/generate-speech", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, gender, accent, emotion, speed: speed[0] }),
      })

      const data = await response.json()
      const endTime = Date.now()
      const duration = (endTime - startTime) / 1000

      onGenerate(data.audioUrl, duration)
    } catch (error) {
      console.error("Error generating speech:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <Textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Enter text to synthesize..."
          className="min-h-[120px] resize-none"
        />
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <div className="space-y-2">
          <Label className="text-xs font-medium text-primary bg-secondary px-2 py-1 rounded inline-block">Gender</Label>
          <Select value={gender} onValueChange={setGender}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="auto">Auto</SelectItem>
              <SelectItem value="male">Male</SelectItem>
              <SelectItem value="female">Female</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label className="text-xs font-medium text-primary bg-secondary px-2 py-1 rounded inline-block">Accent</Label>
          <Select value={accent} onValueChange={setAccent}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="auto">Auto</SelectItem>
              <SelectItem value="northern">Northern</SelectItem>
              <SelectItem value="southern">Southern</SelectItem>
              <SelectItem value="central">Central</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label className="text-xs font-medium text-primary bg-secondary px-2 py-1 rounded inline-block">
            Emotion
          </Label>
          <Select value={emotion} onValueChange={setEmotion}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="auto">Auto</SelectItem>
              <SelectItem value="neutral">Neutral</SelectItem>
              <SelectItem value="happy">Happy</SelectItem>
              <SelectItem value="sad">Sad</SelectItem>
              <SelectItem value="angry">Angry</SelectItem>
              <SelectItem value="surprised">Surprised</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <Label className="text-xs font-medium text-primary bg-secondary px-2 py-1 rounded">Speed</Label>
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium">{speed[0]}</span>
            <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => setSpeed([1])}>
              ⟲
            </Button>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-xs text-muted-foreground">0.5</span>
          <Slider value={speed} onValueChange={setSpeed} min={0.5} max={2} step={0.1} className="flex-1" />
          <span className="text-xs text-muted-foreground">2</span>
        </div>
      </div>

      <Collapsible open={isVoiceCloningOpen} onOpenChange={setIsVoiceCloningOpen}>
        <CollapsibleTrigger className="flex items-center gap-2 text-sm font-medium hover:text-primary transition-colors">
          Voice Cloning (Optional)
          <ChevronDown className={`h-4 w-4 transition-transform ${isVoiceCloningOpen ? "rotate-180" : ""}`} />
        </CollapsibleTrigger>
        <CollapsibleContent className="mt-4">
          <div className="space-y-3 rounded-lg border border-border p-4 bg-muted/30">
            <p className="text-sm text-muted-foreground">
              Upload a 10-15 second audio sample and provide the transcript to clone a voice.
            </p>
            <Button variant="outline" className="w-full bg-transparent">
              Upload Audio Sample
            </Button>
            <Textarea placeholder="Enter the transcript of the audio sample..." className="min-h-[80px] resize-none" />
          </div>
        </CollapsibleContent>
      </Collapsible>

      <Button
        onClick={handleGenerate}
        disabled={isGenerating || !text.trim()}
        className="w-full h-12 text-base font-medium"
      >
        {isGenerating ? (
          <>
            <Loader2 className="mr-2 h-5 w-5 animate-spin" />
            Generating Speech...
          </>
        ) : (
          "Generate Speech"
        )}
      </Button>
    </div>
  )
}
